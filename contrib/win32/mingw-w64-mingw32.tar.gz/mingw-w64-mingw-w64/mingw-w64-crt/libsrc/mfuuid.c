
#include <windows.h>
#include <propsys.h>
#include <mediaobj.h>

#include <initguid.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
