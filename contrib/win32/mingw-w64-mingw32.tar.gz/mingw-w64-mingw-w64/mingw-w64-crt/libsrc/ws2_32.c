#include <winsock2.h>
#include <ws2tcpip.h>

/*  IPv6 constants for use in structure assignments (RFC 2553).  */
const struct in6_addr in6addr_any = IN6ADDR_ANY_INIT;
const struct in6_addr in6addr_loopback = IN6ADDR_LOOPBACK_INIT;
