#! /bin/sh
set -e
# vlc win32 complie shell by yangxun 
# function define
diagnostic()
{
    echo "$@" 1>&2;
}
checkfail()
{
    if [ ! $? -eq 0 ]; then
        diagnostic "$1"
        exit 1
    fi
}
# arg get
while [ $# -gt 0 ]; do
    case $1 in
        --help|-h)
            echo "Use -a to set Host triplet"
            echo "  i686-w64-mingw32 for Windows 32-bits"
            echo "  x86_64-w64-mingw32 for Windows 64-bits"
            exit 0
            ;;
        -a)
            HOST_TRIPLET=$2
            shift
            ;;
    esac
    shift
done
# set default host triplet
if [ -z ${HOST_TRIPLET} ]; then
    #diagnostic "*** No HOST_TRIPLET defined,using i686-w64-mingw32"
    diagnostic "*** No HOST_TRIPLET defined,using -a to set it"
    exit 1
    #HOST_TRIPLET="i686-w64-mingw32"
else
    diagnostic "*** HOST_TRIPLET=${HOST_TRIPLET}"
fi
# detect build folder
if [ ${HOST_TRIPLET} = "i686-w64-mingw32" ]; then
    MY_BUILD_FOLDER="win32"
fi
if [ ${HOST_TRIPLET} = "x86_64-w64-mingw32" ]; then
    MY_BUILD_FOLDER="win64"
fi
# built
CONTRIB_CONFIG="
 --disable-gcrypt
 --disable-ssh2
 --disable-vncclient
 --disable-projectM
 --disable-bluray
 --disable-qt
 --disable-qtsvg
 --disable-sdl
 --disable-SDL_image
 --enable-glew"
mkdir -p contrib/${MY_BUILD_FOLDER}
cd contrib/${MY_BUILD_FOLDER}
../bootstrap --host=${HOST_TRIPLET} ${CONTRIB_CONFIG}
make fetch
checkfail "contrib fetch failed"
make
checkfail "contrib make failed"
rm -f ../i686-w64-mingw32/bin/moc ../i686-w64-mingw32/bin/uic ../i686-w64-mingw32/bin/rcc
if [ ${HOST_TRIPLET} != "i686-w64-mingw32" ]; then
    ln -sf ${HOST_TRIPLET} ../i686-w64-mingw32
fi
# go back
cd -
# compile vlc
OPTIONS="
      --enable-update-check
      --enable-lua
      --enable-faad
      --enable-flac
      --enable-theora
      --enable-twolame
      --enable-avcodec --enable-merge-ffmpeg
      --enable-dca
      --enable-mpc
      --enable-libass
      --enable-x264
      --enable-schroedinger
      --enable-realrtsp
      --enable-live555
      --enable-dvdread
      --enable-shout
      --enable-goom
      --enable-caca
      --enable-qt
      --enable-skins2
      --enable-sse --enable-mmx
      --enable-libcddb
      --enable-zvbi --disable-telx
      --enable-nls
      --disable-update-check
      --disable-libcrypt
      --disable-lua
      --disable-goom
      --disable-projectm
      --disable-vsxu
      --disable-vnc
      --disable-vcd
      --disable-libcddb
      --disable-freerdp
      --disable-opencv
      --disable-dc1394
      --disable-dv1394
      --disable-dvdread
      --disable-dvdnav
      --disable-bluray
      --disable-sdl-image
      --disable-skins2
      --disable-qt"
 
./bootstrap
mkdir -p ${MY_BUILD_FOLDER} && cd ${MY_BUILD_FOLDER}
export PKG_CONFIG_LIBDIR=$HOME/vlc/contrib/${HOST_TRIPLET}/lib/pkgconfig
../configure --host=${HOST_TRIPLET} --build=x86_64-pc-linux-gnu ${OPTIONS}
make
checkfail "vlc make failed"
make package-win32-zip
checkfail "vlc make package failed"

